var slidePosition = 0;
const slides = document.querySelectorAll('.carousel-slide');
const track = document.querySelector('.carousel-track');
const totalSlides = slides.length;

function updateSlidePosition() {
    // Calculate the new position for the track
    track.style.transform = 'translateX(' + (-slidePosition * 100) + '%)';
    updateDots();
}

function plusSlides(n) {
    slidePosition += n;
    if (slidePosition >= totalSlides) {
        slidePosition = 0;
    }
    if (slidePosition < 0) {
        slidePosition = totalSlides - 1;
    }
    updateSlidePosition();
}

function currentSlide(n) {
    slidePosition = n - 1;
    updateSlidePosition();
}

function updateDots() {
    const dots = document.querySelectorAll('.dots');
    dots.forEach((dot, index) => {
        dot.classList.toggle('enable', index === slidePosition);
    });
}

// Initialize with the first slide
updateSlidePosition();