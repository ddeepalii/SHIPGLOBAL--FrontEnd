// Function to move todos to the next category
function moveToNext(status) {
    const listMap = {
        'backlog': 'todo',
        'todo': 'ongoing',
        'ongoing': 'done'
    };
    moveTodoItem(status, listMap[status]);
}

// Function to move todos to the previous category
function moveToPrev(status) {
    const listMap = {
        'todo': 'backlog',
        'ongoing': 'todo',
        'done': 'ongoing'
    };
    moveTodoItem(status, listMap[status]);
}

// Helper function to move todo item between lists
function moveTodoItem(current, target) {
    const currentList = document.getElementById(`${current}-list`);
    const targetList = document.getElementById(`${target}-list`);
    const item = currentList.querySelector('.todo-item');
    if (item) {
        targetList.appendChild(item);
    }
}
