// Generate a random number between 1 and 100
let randomNumber = Math.floor(Math.random() * 100) + 1;

// Set the number of attempts the user has
let attempts = 5;

// Select the elements from the DOM (HTML) that display the number of attempts, the input field, 
// the check button, the feedback message, and the reset button
const attemptsDisplay = document.getElementById('attempts');
const input = document.getElementById('input');
const check = document.getElementById('check');
const feedback = document.getElementById('feedback');
const resetButton = document.getElementById('reset');

// Display the initial number of attempts available to the user
attemptsDisplay.textContent = `You have ${attempts} Chances`;

// Add an event listener for the 'click' event on the 'check' button
check.addEventListener('click', () => {
    // Parse the user's guess from the input field as an integer
    const userGuess = parseInt(input.value);

    // Decrease the attempts count by 1 each time the check button is clicked
    --attempts;
    attemptsDisplay.textContent = `You have ${attempts} Chances`;

    // Check if the input is not a number
    if (isNaN(userGuess)) {
        feedback.textContent = 'Not a Number';
        return; // Exit the function if input is not a valid number
    }

    // Check if the input number is out of the valid range (1 to 100)
    if (userGuess < 1 || userGuess > 100) {
        feedback.textContent = 'Number out of range';
        return; // Exit the function if number is out of range
    }

    // Check if the user has run out of attempts
    if (attempts === 0) {
        feedback.textContent = `Your attempt is over. The correct number was ${randomNumber}. Try again!`;
        check.disabled = true; // Disable the check button as no attempts are left
        resetButton.style.display = 'inline-block'; // Show the reset button
        return; // Exit the function
    }

    // Check if the user's guess is correct
    if (userGuess === randomNumber) {
        feedback.textContent = `Congratulations! You guessed the correct number ${randomNumber}.`;
        check.disabled = true; // Disable the check button as the correct number was guessed
        resetButton.style.display = 'inline-block'; // Show the reset button
    } else if (userGuess < randomNumber) {
        // If the guess is too low, inform the user
        feedback.textContent = 'Your guess is too low.';
    } else {
        // If the guess is too high, inform the user
        feedback.textContent = 'Your guess is too high.';
    }
});

// Add an event listener for the 'click' event on the 'reset' button
resetButton.addEventListener('click', () => {
    // Generate a new random number between 1 and 100
    randomNumber = Math.floor(Math.random() * 100) + 1;

    // Reset the number of attempts
    attempts = 5;

    // Clear any feedback message and update the attempts display
    feedback.textContent = '';
    attemptsDisplay.textContent = `You have ${attempts} Chances`;

    // Clear the input field, re-enable the check button, and hide the reset button
    input.value = '';
    check.disabled = false;
    resetButton.style.display = 'none';
});
